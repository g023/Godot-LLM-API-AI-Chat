#!/bin/sh
echo -ne '\033c\033]0;LLM Local or Remote API GPT Chat Access\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/LLM Local or Remote API GPT Chat Access.v0_01_Mar21_2024.x86_64" "$@"
